## Analyse de l'Entropie des Concepts OpenAlex en Informatique Quantique Ouverte

Ce readme contient les résultats de notre analyse de l'entropie des concepts extraits de la base de données OpenAlex, spécifiquement axée sur le domaine de l'informatique quantique ouverte. L'objectif de cette étude est de comprendre la diversité et la concentration des thèmes abordés dans la littérature scientifique liée à ce domaine, en utilisant le concept d'entropie pour quantifier cette diversité.


### Méthodologie

Nous avons utilisé les données d'OpenAlex pour identifier les publications et leurs concepts associés dans le champ de l'informatique quantique ouverte. Pour chaque ensemble de concepts (selon les axes de nos analyses), nous avons calculé l'entropie  afin de mesurer l'incertitude ou la diversité de distribution des concepts. Une entropie élevée indique une grande variété de concepts, tandis qu'une entropie faible suggère une concentration sur un nombre limité de thèmes.


### Graphiques d'Analyse

Vous trouverez ci-dessous une description des trois graphiques , chacun offrant une perspective unique sur l'entropie des concepts :

#### 1. Evolution annuelle de l'entropie de 2020 a 2023

 Ce graphique(evolution annuelle de l'entropie.png) illustre l'évolution annuelle de l'entropie des concepts OpenAlex de 2020 à 2023. L'entropie, mesurée en bits, a significativement augmenté de 2020 à 2022, passant d'environ 9.32 à un pic de plus de 9.92 bits. Cette hausse indique une diversité et une complexité croissantes des concepts au sein d'OpenAlex durant cette période. Cependant, en 2023, on observe une légère diminution de l'entropie, autour de 9.85 bits, suggérant une possible stabilisation ou une légère réduction de cette diversité par rapport à l'année précédente.

#### 2. evolution de l'entropie au fil du temps

Le graphique intitulé "Évolution de l'entropie au fil du temps" présente les variations de l'entropie sur une période s'étendant du début de l'année 2020 à la fin de l'année 2023. L'entropie, souvent interprétée comme une mesure du désordre ou du caractère aléatoire, montre des fluctuations significatives tout au long de cette période.

Au début de l'année 2020, l'entropie est élevée, suivie d'une baisse puis d'un pic vers la fin de l'année 2020 / début 2021, atteignant son point le plus haut sur le graphique. Cette période semble être caractérisée par une instabilité ou des changements imprévisibles considérables. Par la suite, on observe une tendance générale d'oscillations, l'entropie revenant parfois à des niveaux plus élevés (par exemple, mi-2022 et mi-2023) et à d'autres moments chutant de manière significative (par exemple, fin 2022 et début 2023).

Les pics et les creux récurrents suggèrent que le système mesuré traverse des phases alternées de désordre/aléatoire accru et d'ordre/prévisibilité relatif. Il ne semble pas y avoir de tendance claire et constante à la hausse ou à la baisse de l'entropie sur l'ensemble de la période, ce qui indique que le système ne devient pas constamment plus chaotique ou plus ordonné. Au contraire, il semble être dans un équilibre dynamique, basculant constamment entre différents états d'entropie. La volatilité à court terme est une caractéristique clé de ces données, ce qui implique que les facteurs influençant l'entropie sont sujets à des changements fréquents et substantiels.

#### 3.entropie de la distribution des concepts par date de publication 

Ce graphique présente l'évolution de l'entropie de la distribution des concepts au fil du temps, entre le 1er janvier et le 22 avril 2025. L'entropie, ici mesurée en bits, reflète une mesure de diversité ou d’incertitude dans les concepts abordés à chaque date de publication.

 Ce que cela signifie :

- Valeurs d’entropie élevées: indiquent que les concepts sont variés et peu concentrés : plusieurs idées ou thèmes sont présents sans qu’un seul ne domine. Cela traduit une production plus diversifiée ou exploratoire à ces dates.

- Valeurs faibles d’entropie: suggèrent au contraire que certains concepts sont largement dominants, réduisant la diversité globale. Ces périodes peuvent correspondre à une focalisation sur des sujets spécifiques ou à une baisse de la créativité conceptuelle.

### Analyse temporelle :

- On peut observer des variations importantes d’un jour à l’autre. Cela signifie que la dynamique de création ou de publication est irrégulière, ce qui peut être lié à :
  - des événements particuliers déclenchant une concentration sur certains thèmes ;
  - des phases de recherche ou d’expérimentation conceptuelle (haute entropie) suivies de périodes de synthèse ou d’approfondissement (basse entropie).

### Hypothèses intéressantes :

- Si cette entropie est liée à la production d’un modèle d’intelligence artificielle ou à un système éditorial, elle peut indiquer les moments où les idées étaient le plus riches** ou, au contraire, où une direction éditoriale plus stricte a été imposée.
- Des pics d’entropie pourraient signaler des phases de brainstorming collectif ou des changements dans la composition des auteurs ou des sources d’inspiration.



### Comment Utiliser Ces Informations ?

Ces analyses d'entropie peuvent être utilisées pour :

- Identifier les tendances émergentes : Une augmentation de l'entropie dans certains domaines ou au fil du temps peut signaler de nouvelles directions de recherche.
- Comprendre la maturité du domaine : Une entropie stable pourrait indiquer un domaine mature avec des thèmes bien définis.
- Orienter la recherche future : Les domaines ou types de publications avec une faible entropie pourraient représenter des opportunités pour des explorations conceptuelles plus diverses.


